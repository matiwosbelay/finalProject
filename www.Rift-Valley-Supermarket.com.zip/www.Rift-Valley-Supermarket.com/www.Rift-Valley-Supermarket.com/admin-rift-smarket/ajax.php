<?php
/**
 * ajax front controller (admin version)
 *
 * NOTE: "Assumes" that the admin directory is a direct subdirectory off the store's file-system!
 */
// -----
// Let the "base" ajax.php processing "know" that this request came from the admin,
// so that the admin version of the application_top.php processing will be loaded.
//
$zc_ajax_base_dir = basename(dirname(__FILE__)) . DIRECTORY_SEPARATOR;
require '../ajax.php';
