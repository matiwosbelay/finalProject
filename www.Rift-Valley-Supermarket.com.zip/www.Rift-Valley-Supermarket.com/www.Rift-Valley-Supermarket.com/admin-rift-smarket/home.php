<?php

$version_check_index=true;
require('includes/application_top.php');

$languages = rift_get_languages();
$languages_array = array();
$languages_selected = DEFAULT_LANGUAGE;
for ($i = 0, $n = sizeof($languages); $i < $n; $i++) {
    $languages_array[] = array('id' => $languages[$i]['code'],
                               'text' => $languages[$i]['name']);
    if ($languages[$i]['directory'] == $_SESSION['language']) {
        $languages_selected = $languages[$i]['code'];
    }
}

if (STORE_NAME == '' || STORE_OWNER =='' || STORE_OWNER_EMAIL_ADDRESS =='' || STORE_NAME_ADDRESS =='') {
    require('index_setup_wizard.php');
} else {
    require('index_dashboard.php');
}
?>
    <footer class="homeFooter">
        <!-- The following copyright announcement is in compliance
        to section 2c of the GNU General Public License, and
        thus can not be removed, or can only be modified
        appropriately. //-->

        <div class="copyrightrow"><img src="images/small_riftvalley_logo.gif" alt="Rift Valley Super Market" /><br /><br />E-Commerce Engine Copyright &copy;<?php echo date('Y'); ?> Rift Valley University Students </div>
        
       
    </footer>
    </body>
    </html>
<?php require('includes/application_bottom.php');
