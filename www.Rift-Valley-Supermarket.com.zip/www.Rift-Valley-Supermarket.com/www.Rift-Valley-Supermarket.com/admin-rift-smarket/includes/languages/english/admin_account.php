<?php

define('HEADING_TITLE', 'Admin Account');
require DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . 'users.php'; 
