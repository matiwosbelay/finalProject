<?php

define('TABLE_HEADING_COMMENTS', 'Comments');
define('TABLE_HEADING_CUSTOMER_NOTIFIED', 'Customer Notified');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TABLE_HEADING_STATUS', 'Status');

define('TABLE_HEADING_PRODUCTS', 'Products');

define('ENTRY_CUSTOMER', 'CUSTOMER:');

define('ENTRY_SOLD_TO', 'BILL TO:');
define('ENTRY_SHIP_TO', 'SHIP TO:');
define('ENTRY_PAYMENT_METHOD', 'Payment Method:');
define('ENTRY_DATE_PURCHASED', 'Date Ordered:');

define('ENTRY_ORDER_ID','Order No. ');
