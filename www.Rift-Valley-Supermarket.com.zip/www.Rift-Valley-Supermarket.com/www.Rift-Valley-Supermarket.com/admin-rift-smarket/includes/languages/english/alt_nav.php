<?php

define('HEADING_TITLE', 'Alternative Navigation');
