<?php

define('HEADING_TITLE', 'Most-Viewed Products');

define('TABLE_HEADING_NUMBER', 'Product ID');
define('TABLE_HEADING_PRODUCTS', 'Product Name (Language)');
define('TABLE_HEADING_VIEWED', 'Views');
define('TEXT_REPORT_START_DATE', 'Start Date');
define('TEXT_REPORT_END_DATE', 'End Date');
