<?php

define('HEADING_TITLE', 'Product Stock Report');

define('TABLE_HEADING_NUMBER', 'ID#');
define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_VIEWED', 'Quantity');
?>