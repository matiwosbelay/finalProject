<?php

define('TEXT_ACCESS_DENIED', 'Sorry, your security clearance does not allow you to access this resource.');
define('TEXT_CONTACT_SITE_ADMIN', 'Please contact your site administrator if you believe this to be incorrect.');
define('TEXT_APOLOGY', 'Sorry for any inconvenience.');