<?php

define('HEADING_TITLE', 'Products Expected');

define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_DATE_EXPECTED', 'Date Expected:');
?>