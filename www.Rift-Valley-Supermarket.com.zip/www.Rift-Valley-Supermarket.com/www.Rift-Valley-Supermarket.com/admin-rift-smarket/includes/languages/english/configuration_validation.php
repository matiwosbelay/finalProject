<?php
 
 define('TEXT_EMAIL_ADDRESS_VALIDATE', 'The text entered does not resolve to an acceptable email address. (I.e. Name &lt;email@domain&gt; or &lt;email@domain&gt; or email@domain or any combination of these separated by a comma.)');
 define('TEXT_BOOLEAN_VALIDATE', 'The value is required to be a boolean value or equivalent.');