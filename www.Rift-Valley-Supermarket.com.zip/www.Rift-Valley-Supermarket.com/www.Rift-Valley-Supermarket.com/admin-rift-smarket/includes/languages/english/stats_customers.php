<?php

define('HEADING_TITLE', 'Best Customer Orders-Total');

define('TABLE_HEADING_NUMBER', 'ID#');
define('TABLE_HEADING_CUSTOMERS', 'Customers');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Total Purchased');
?>