<?php

define('HEADING_TITLE', 'Salemaker');
define('SUBHEADING_TITLE', 'Salemaker Usage Tips:');

define('TEXT_SALEMAKER_IMMEDIATELY', 'Immediately');
define('TEXT_SALEMAKER_NEVER', 'Never');
define('TEXT_CLOSE_WINDOW', '[ close window ]');
define('TABLE_HEADING_SALE_NAME', 'SaleName');
define('TABLE_HEADING_SALE_DEDUCTION', 'Deduction');
define('TABLE_HEADING_SALE_DATE_START', 'Startdate');
define('TABLE_HEADING_SALE_DATE_END', 'Enddate');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Action');
?>