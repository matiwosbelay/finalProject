<?php

  define('HEADING_TITLE', 'Customers Referral Report');
  define('TEXT_INFO_SELECT_REFERRAL','Select a Referral/Coupon Code');
  define('TEXT_REFERRAL_UNKNOWN', 'Unknown');
  define('TEXT_INFO_START_DATE', 'Start Date (m-d-y)');
  define('TEXT_INFO_END_DATE', 'End Date (m-d-y)');
  define('TEXT_ORDER_NUMBER', 'Order #');
  define('TEXT_COUPON_ID', 'Discount Coupon ID#');
