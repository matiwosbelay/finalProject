<?php

define('TEXT_DOCUMENT_STATUS', 'Document Status:');
define('TEXT_DOCUMENT_DATE_AVAILABLE', 'Date Available:');
define('TEXT_DOCUMENT_AVAILABLE', 'Available');
define('TEXT_DOCUMENT_NAME', 'Document Name:');
define('TEXT_DOCUMENT_DETAILS', 'Document Contents:');
define('TEXT_DOCUMENT_IMAGE', 'Document Image:');
define('TEXT_DOCUMENT_IMAGE_DIR', 'Upload to directory:');
define('TEXT_DOCUMENT_URL', 'Document URL:');
define('TEXT_DOCUMENT_URL_WITHOUT_HTTP', '<small>(without http://)</small>');
