<?php

  define('EDITOR_CKEDITOR', 'CKEditor');
