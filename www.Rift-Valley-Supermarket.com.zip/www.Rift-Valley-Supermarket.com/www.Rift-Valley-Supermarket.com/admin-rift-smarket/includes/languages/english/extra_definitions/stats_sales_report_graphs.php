<?php

define('BOX_REPORTS_SALES_REPORT_GRAPHS', 'Sales Report with Graphs');

