<?php

/**
 * Security Patch v138 20090619
 * @package patches
 */

/////// NOTE: THIS FILE NO LONGER RELEVANT in v1.3.9 and higher.  PLEASE DELETE FROM YOUR SERVER.