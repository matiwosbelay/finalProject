<?php

if (function_exists('rift_register_admin_page')) {
    if (!rift_page_key_exists ('reportSalesWithGraphs')) {
        rift_register_admin_page('reportSalesWithGraphs', 'BOX_REPORTS_SALES_REPORT_GRAPHS', 'FILENAME_STATS_SALES_REPORT_GRAPHS', '', 'reports', 'Y', 15);
    }
}
