<?php

if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
/////// NOTE: THIS FILE NO LONGER RELEVANT in v1.5.7 and higher.  PLEASE DELETE FROM YOUR SERVER.

// (The Admin now shares the catalog version of this class.)
