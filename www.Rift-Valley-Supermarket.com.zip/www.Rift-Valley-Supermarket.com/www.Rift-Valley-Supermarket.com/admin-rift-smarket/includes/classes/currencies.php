<?php

include DIR_FS_CATALOG . DIR_WS_CLASSES . 'currencies.php'; 
