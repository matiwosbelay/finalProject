<?php

// get time zone settings from catalog-side file
include (DIR_FS_CATALOG . '/includes/extra_configures/set_time_zone.php');
