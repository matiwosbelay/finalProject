<?php
/**
 * Very simple error logging to file
 *
 * Sometimes it is difficult to debug PHP background activities, especially when most information cannot be safely output to the screen.
 * However, using the PHP error logging facility we can store all PHP errors to a file, and then review separately.
 * Using this method, the debug details are stored at: /logs/myDEBUG-adm-999999-00000000.log
 * Credits to @lat9 for adding backtrace functionality
 *
 */
require DIR_FS_CATALOG . 'includes/extra_configures/enable_error_logging.php';