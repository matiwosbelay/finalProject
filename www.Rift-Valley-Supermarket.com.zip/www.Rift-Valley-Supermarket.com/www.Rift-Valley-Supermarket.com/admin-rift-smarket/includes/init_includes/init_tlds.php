<?php

if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
$http_domain = rift_get_top_level_domain(HTTP_SERVER);
$cookieDomain = $http_domain;
if (defined('HTTP_COOKIE_DOMAIN'))
{
  $cookieDomain = HTTP_COOKIE_DOMAIN;
}