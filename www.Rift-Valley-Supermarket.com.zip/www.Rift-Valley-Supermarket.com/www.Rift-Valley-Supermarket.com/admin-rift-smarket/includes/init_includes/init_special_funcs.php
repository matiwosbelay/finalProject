<?php

if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
// set a default time limit
  rift_set_time_limit(GLOBAL_SET_TIME_LIMIT);

// auto activate and expire banners
  require(DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'banner.php');
  rift_activate_banners();
  rift_expire_banners();

// auto expire special products
  require(DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'specials.php');
  rift_start_specials();
  rift_expire_specials();

// auto expire featured products
  require(DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'featured.php');
  rift_start_featured();
  rift_expire_featured();

// auto expire salemaker sales
  require(DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'salemaker.php');
  rift_start_salemaker();
  rift_expire_salemaker();

?>