<?php

  require('includes/application_top.php');
  unset($_SESSION['admin_id']);
  rift_session_destroy();
  require('includes/application_bottom.php');
  rift_redirect(rift_href_link(FILENAME_LOGIN, '', 'SSL'));
  exit();