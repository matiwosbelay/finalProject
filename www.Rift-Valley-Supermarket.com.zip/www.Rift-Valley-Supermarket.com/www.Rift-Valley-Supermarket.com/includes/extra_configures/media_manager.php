<?php
/** 
 * sundry defines for the music product type
 */
/**
 * The directory where media (mp3's etc) are stored - relative to catalog dir.
 */
  define('DIR_WS_MEDIA', 'media/');
?>