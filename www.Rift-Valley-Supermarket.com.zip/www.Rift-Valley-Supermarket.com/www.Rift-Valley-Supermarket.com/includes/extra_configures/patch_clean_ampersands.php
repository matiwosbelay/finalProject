<?php

/**
 * Non-sanitization/access - $_GET
 * Please Note : This file should be placed in includes/extra_configures and will automatically load.  
 */

if (!isset($_GET)) {
    return;
}
if (!is_array($_GET)) {
    return;
}
foreach ($_GET as $key => $value) {
    if ($key === 'amp;') continue;
    if (strpos($key, 'amp;') !== 0) {
        continue;
    }
    $newtext = substr($key, 4);
    if (isset($_GET[$newtext])) continue;

    $_GET[$newtext] = $_GET['amp;' . $newtext];
    unset($_GET['amp;' . $newtext]);
}

