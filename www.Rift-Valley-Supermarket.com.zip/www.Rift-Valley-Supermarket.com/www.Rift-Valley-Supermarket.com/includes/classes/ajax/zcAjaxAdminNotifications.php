<?php
/**
 * zcAjaxAdminNotifications
 */
class zcAjaxAdminNotifications extends base
{

    public function forget()
    {
        global $db;

        if (!isset($_POST['key'])) {
            return (array(
                'data' => false
            ));
        }

        $sql = "INSERT INTO " . TABLE_ADMIN_NOTIFICATIONS . "(notification_key, admin_id, dismissed) VALUE (:nKey:,:adminId:, 1) 
               ON DUPLICATE KEY UPDATE notification_key = :nKey:, admin_id = :adminId:, dismissed = 1";

        $sql = $db->bindVars($sql, ':adminId:', $_POST['admin_id'], 'integer');
        $sql = $db->bindVars($sql, ':nKey:', $_POST['key'], 'string');
        $result = $db->execute($sql);

        return (array(
            'data' => $result
        ));
    }

}
