<?php

namespace Riftvalley\TableViewControllers;

interface TableViewController
{


}