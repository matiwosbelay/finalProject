<?php
/** 
 * File contains just the notifier class
 */
/**
 * class notifier is a concrete implemetation of the abstract base class
 *
 * it can be used in procedural (non OOP) code to set up an observer
 * see the observer/notifier tutorial for more details.
 */
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
class notifier extends base {
}
?>