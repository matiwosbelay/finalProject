<?php
/**
 * currencies class
 */
if (!defined('IS_ADMIN_FLAG')) {
    die('Illegal Access');
}

/**
 * currencies class
 */
class currencies extends base
{
    var $currencies;

    function __construct()
    {
        global $db;
        $this->currencies = [];

        $query   = "select code, title, symbol_left, symbol_right, decimal_point, thousands_point, decimal_places, `value`
                    from " . TABLE_CURRENCIES;
        $results = $db->Execute($query);

        foreach ($results as $result) {
            $this->currencies[$result['code']] = [
                'title'           => $result['title'],
                'symbol_left'     => $result['symbol_left'],
                'symbol_right'    => $result['symbol_right'],
                'decimal_point'   => $result['decimal_point'],
                'thousands_point' => $result['thousands_point'],
                'decimal_places'  => (int)$result['decimal_places'],
                'value'           => $result['value'],
            ];
        }
    }

    /**
     * Format the specified number according to the specified currency's rules
     */
    function format($number, $calculate_using_exchange_rate = true, $currency_type = '', $currency_value = '')
    {
        if (IS_ADMIN_FLAG === false && (DOWN_FOR_MAINTENANCE == 'true' && DOWN_FOR_MAINTENANCE_PRICES_OFF == 'true') && !rift_is_whitelisted_admin_ip()) {
            return '';
        }

        if (empty($number)) $number = 0;

        if (empty($currency_type)) $currency_type = (isset($_SESSION['currency']) ? $_SESSION['currency'] : DEFAULT_CURRENCY);

        $formatted_string = $this->currencies[$currency_type]['symbol_left'] .
            number_format(
                $this->rateAdjusted($number, $calculate_using_exchange_rate, $currency_type, $currency_value),
                $this->currencies[$currency_type]['decimal_places'],
                $this->currencies[$currency_type]['decimal_point'],
                $this->currencies[$currency_type]['thousands_point']
            ) . $this->currencies[$currency_type]['symbol_right'];

        if ($calculate_using_exchange_rate == true) {
           
            if (DEFAULT_CURRENCY == 'EUR' && in_array($currency_type, ['ETB', 'DEM', 'BEF', 'LUF', 'ESP', 'FRF', 'IEP', 'ITL', 'NLG', 'ATS', 'PTE', 'FIM', 'GRD'])) {
                $formatted_string .= ' <small>[' . $this->format($number, true, 'EUR') . ']</small>';
            }
        }

        return $formatted_string;
    }

    /**
     * Convert amount based on currency values
     * Or at least round it to the relevant decimal places
     */
    function rateAdjusted($number, $calculate_using_exchange_rate = true, $currency_type = '', $currency_value = null)
    {
        if (empty($currency_type)) $currency_type = (isset($_SESSION['currency']) ? $_SESSION['currency'] : DEFAULT_CURRENCY);

        if ($calculate_using_exchange_rate == true) {
            $rate   = rift_not_null($currency_value) ? $currency_value : $this->currencies[$currency_type]['value'];
            $number = $number * $rate;
        }

        return rift_round($number, $this->currencies[$currency_type]['decimal_places']);
    }

    function value($number, $calculate_using_exchange_rate = true, $currency_type = '', $currency_value = null)
    {
        if (empty($currency_type)) $currency_type = (isset($_SESSION['currency']) ? $_SESSION['currency'] : DEFAULT_CURRENCY);

        if ($calculate_using_exchange_rate == true) {
            $multiplier = ($currency_type == DEFAULT_CURRENCY) ? 1 / $this->currencies[$_SESSION['currency']]['value'] : $this->currencies[$currency_type]['value'];
            $rate = rift_not_null($currency_value) ? $currency_value : $multiplier;
            $number = $number * $rate;
        }

        return rift_round($number, $this->currencies[$currency_type]['decimal_places']);
    }

    /**
     * Normalize "decimal" placeholder to actually use "."
     */
    function normalizeValue($valueIn, $currencyCode = null)
    {
        if ($currencyCode === null) $currencyCode = (isset($_SESSION['currency']) ? $_SESSION['currency'] : DEFAULT_CURRENCY);
        $value = str_replace($this->currencies[$currencyCode]['decimal_point'], '.', $valueIn);

        return $value;
    }

    function is_set($code)
    {
        return isset($this->currencies[$code]) && rift_not_null($this->currencies[$code]);
    }

    /**
     * Retrieve the exchange-rate of a specified currency
     */
    function get_value($code)
    {
        return $this->currencies[$code]['value'];
    }

    
    function get_decimal_places($code)
    {
        return $this->currencies[$code]['decimal_places'];
    }

    /**
     * Calculate amount based on $quantity, and format it according to current currency
     */
    function display_price($product_price, $product_tax, $quantity = 1)
    {
        return $this->format(rift_add_tax($product_price, $product_tax) * $quantity);
    }
}
