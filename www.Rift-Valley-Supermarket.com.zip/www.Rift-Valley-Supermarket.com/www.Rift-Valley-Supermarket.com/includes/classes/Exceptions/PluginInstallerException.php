<?php
namespace Riftvalley\Exceptions;

class PluginInstallerException extends \Exception
{

}