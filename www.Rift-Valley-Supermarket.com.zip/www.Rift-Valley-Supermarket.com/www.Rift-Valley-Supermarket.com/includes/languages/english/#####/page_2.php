<?php

define('NAVBAR_TITLE', 'Page 2');
define('HEADING_TITLE', 'Page 2');

define('TEXT_INFORMATION', 'Page 2 information goes here.');
?>