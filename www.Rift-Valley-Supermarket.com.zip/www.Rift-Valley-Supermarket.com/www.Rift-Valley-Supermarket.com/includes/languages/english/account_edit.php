<?php


define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Edit Account');

define('HEADING_TITLE', 'My Account Information');

define('SUCCESS_ACCOUNT_UPDATED', 'Your account has been successfully updated.');
?>
