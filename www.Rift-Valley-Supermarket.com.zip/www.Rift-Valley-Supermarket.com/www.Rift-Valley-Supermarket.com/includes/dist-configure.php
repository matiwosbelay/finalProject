<?php
/**
 * This file is VERY similar to, but DIFFERENT from the "admin" version of configure.php. 
 * The 2 files should be kept separate and not used to overwrite each other.   

 * HTTP_SERVER is your Main webserver
 * HTTPS_SERVER is your Secure/SSL webserver
 */
define('HTTP_SERVER', 'http://localhost');
define('HTTPS_SERVER', 'https://localhost');
/* For login and checkout, set this to 'true'. Otherwise 'false'. (Keep the quotes) */
define('ENABLE_SSL', 'true');


define('DIR_WS_CATALOG', '/');
define('DIR_WS_HTTPS_CATALOG', '/');

/**
 * This is the complete physical path to your store's files.  eg: /var/www/vhost/accountname/public_html/store/
 * Should have a closing / on it.
 */
define('DIR_FS_CATALOG', '/var/www/vhost/accountname/public_html/store/');

define('DB_TYPE', 'mysql'); // always 'mysql'
define('DB_PREFIX', ''); // prefix for database table names -- preferred to be left empty
define('DB_CHARSET', 'utf8'); // 'utf8' or 'latin1' are most common
define('DB_SERVER', 'localhost');  // address of your db server
define('DB_SERVER_USERNAME', '');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', '');

define('SQL_CACHE_METHOD', 'none');

/* Reserved for future use */
define('SESSION_STORAGE', 'temporary value added by zc_install');
