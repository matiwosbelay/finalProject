<?php
/**
 * compatibility functions
 */


// This file is empty in v1.5.2
