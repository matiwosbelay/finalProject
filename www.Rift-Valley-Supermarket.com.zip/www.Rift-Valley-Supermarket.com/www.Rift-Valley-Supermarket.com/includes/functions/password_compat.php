<?php
/**
 * password_compat functions
*/
if (! defined('PASSWORD_DEFAULT')) {

  define('PASSWORD_BCRYPT', 1);
  define('PASSWORD_DEFAULT', PASSWORD_BCRYPT);

  if (! function_exists('password_hash')) {
    function password_hash($password, $algo = null)
    {
      return rift_encrypt_password_new($password);
    }
  }
  if (! function_exists('password_verify')) {
    function password_verify($plain, $encrypted)
    {
      if (rift_not_null($plain) && rift_not_null($encrypted)) {
        $stack = explode(':', $encrypted);
        if (sizeof($stack) != 2)
          return false;
        if (zcPassword::getInstance(PHP_VERSION)->validatePasswordOldMd5($plain, $encrypted) === true) {
          return true;
        } elseif (zcPassword::getInstance(PHP_VERSION)->validatePasswordCompatSha256($plain, $encrypted) === true) {
          return true;
        }
      }
      return false;
    }
  }
  if (! function_exists('password_needs_rehash')) {
    function password_needs_rehash($hash, $algo = null)
    {
      $tmp = explode(':', $hash);
      if (count($tmp) == 2 && strlen($tmp [1]) == 2) {
        return true;
      } else {
        return false;
      }
    }
  }
}