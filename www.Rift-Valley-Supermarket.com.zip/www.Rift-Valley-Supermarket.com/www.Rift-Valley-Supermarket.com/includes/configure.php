<?php
/**
 * HTTP_SERVER is your Main webserver
 * HTTPS_SERVER is your Secure/SSL webserver
 */
define('HTTP_SERVER', 'http://localhost');
define('HTTPS_SERVER', 'https://localhost');
/* For login and checkout, set this to 'true'. Otherwise 'false'. (Keep the quotes) */
define('ENABLE_SSL', 'true');
/**
 * subdirectory in which the store is located.
 * HTTP_CATALOG_SERVER and HTTPS_CATALOG_SERVER values to form the complete URLs to the storefront.
 */
define('DIR_WS_CATALOG', '/www.Rift-Valley-Supermarket.com/');
define('DIR_WS_HTTPS_CATALOG', '/www.Rift-Valley-Supermarket.com/');
define('DIR_FS_CATALOG', 'C:/xampp/htdocs/www.Rift-Valley-Supermarket.com/');

/**
 * The following settings define your database connection.
 * These must be the SAME as you're using in your admin copy of configure.php
 */
define('DB_TYPE', 'mysql'); // always 'mysql'
define('DB_PREFIX', ''); // prefix for database table names -- preferred to be left empty
define('DB_CHARSET', 'utf8mb4'); // 'utf8mb4' or older 'utf8' / 'latin1' are most common
define('DB_SERVER', 'localhost');  // address of your db server
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', 'rv_db');
/**
 * This is an advanced setting to determine whether you want to cache SQL queries.
 * Options are 'none' (which is the default) and 'file' and 'database'.
 */
define('SQL_CACHE_METHOD', 'database');
/* Reserved for future use */
define('SESSION_STORAGE', 'reserved for future use');
