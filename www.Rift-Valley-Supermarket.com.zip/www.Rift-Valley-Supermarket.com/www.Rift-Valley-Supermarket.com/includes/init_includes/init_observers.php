<?php

  if (!defined('IS_ADMIN_FLAG')) {
   die('Illegal Access');
  }

  // Find observer class files which follow the naming convention "auto.xxxxxxx.php"
  $directory_array = array();
  if ($dir = @dir(DIR_WS_CLASSES . 'observers/')) {
    while ($file = $dir->read()) {
      if (!is_dir($dir->path . '/' . $file)) {
        if (preg_match('~(^auto\..*\.php$)~', $file, $matches) > 0) {
          $directory_array[] = rtrim($dir->path, '/') . '/' . $file;
        }
      }
    }
    $dir->close();
  }

  // instantiate observer classes which follow the naming convention "zcObserver" + CamelCasedVersionOfXxxxxxFromFileName
  foreach ($directory_array as $file) {
    if (file_exists($file)) {
      include($file);
      $objectName = preg_replace('~(^.*/auto\.|\.php$)~', '', $file);
      $objectName = 'zcObserver' . base::camelize($objectName, TRUE);
      if (class_exists($objectName)) {
        $$objectName = new $objectName();
      } else {
        error_log('ERROR: Observer class ' . $objectName . ' could not be instantiated despite file ' . $file . ' being found. Please follow the correct naming convention for the class name inside the file.');
      }
    }
  }


