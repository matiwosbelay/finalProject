<?php
/**
 * if gzip_compression is enabled, start to buffer the output
 */
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
if (!(isset($_GET['main_page']) && $_GET['main_page'] == FILENAME_DOWNLOAD) && (int)GZIP_LEVEL >= 1 && $ext_zlib_loaded = extension_loaded('zlib') && trim(ini_get('output_handler')) == '') {
  if (($ini_zlib_output_compression = (int)ini_get('zlib.output_compression')) < 1) {
    @ini_set('zlib.output_compression', 1);
  }
  if (($ini_zlib_output_compression = (int)ini_get('zlib.output_compression')) < 1) {
    ob_start('ob_gzhandler');
  } else {
    @ini_set('zlib.output_compression_level', (int)GZIP_LEVEL);
  }
}
