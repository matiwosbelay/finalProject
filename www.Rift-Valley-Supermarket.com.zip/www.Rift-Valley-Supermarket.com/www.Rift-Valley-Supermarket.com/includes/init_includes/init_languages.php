<?php

/**
 * initialise language handling
 */
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
if (!isset($_SESSION['language']) || isset($_GET['language'])) {
  $lng = new language();
  if (isset($_GET['language']) && rift_not_null($_GET['language'])) {
    $lng->set_language($_GET['language']);
    $zco_notifier->notify('NOTIFY_LANGUAGE_CHANGE_REQUESTED_BY_VISITOR', $_GET['language'], $lng);
  } else {
    if (LANGUAGE_DEFAULT_SELECTOR == 'Browser') {
      $lng->get_browser_language();
      if (!rift_not_null($lng->language['id'])) {
        $lng->set_language(DEFAULT_LANGUAGE);
      }
    } else {
      $lng->set_language(DEFAULT_LANGUAGE);
    }
  }
  $_SESSION['language'] = (rift_not_null($lng->language['directory']) ? $lng->language['directory'] : 'english');
  $_SESSION['languages_id'] = (rift_not_null($lng->language['id']) ? (int)$lng->language['id'] : 1);
  $_SESSION['languages_code'] = (rift_not_null($lng->language['code']) ? $lng->language['code'] : 'en');
}
